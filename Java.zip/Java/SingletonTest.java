
public class SingletonTest {
	public static void main(String args[]){    
		Singleton a = Singleton.getInstance();   
		Singleton b = Singleton.getInstance();   
		Singleton c = Singleton.getInstance();    
		a.str = (a.str).toUpperCase();   
		System.out.println("String from a is " + a.str);   
		System.out.println("String from b is " + b.str);   
		System.out.println("String from c is " + c.str);   
		}   
}
