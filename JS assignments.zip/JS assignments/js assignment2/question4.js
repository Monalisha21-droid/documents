//square of an array using map function
Array.prototype.square = function () {
    var arr1 = [];
    this.map(function (obj) {
        arr1.push(obj * obj);
    });
    return arr1;
}
arr1 = [1, 2, 3, 4, 5];
document.write(arr1.square());
//squareroot of each element in a array
const numbers = [1, 4, 9, 16, 25];
document.getElementById("th").innerHTML= numbers.map(Math.sqrt);
