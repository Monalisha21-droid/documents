var n=5;
var sum=0;
for(i=1;i<=n;i++){
    sum=sum+i;
}
document.write(sum);