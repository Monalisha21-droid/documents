var num=prompt("enter the number");
function evenOrOdd(num) { 
    if (num % 2 == 0) {
      document.write("even");
    } 
    else {
      document.write("odd");
    }
  }
  evenOrOdd(num);