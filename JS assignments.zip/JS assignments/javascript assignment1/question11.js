const capg_locations = ["Bangalore", "Bhubaneswar", "Pune", "Mumbai"];
document.write(capg_locations.reverse());
