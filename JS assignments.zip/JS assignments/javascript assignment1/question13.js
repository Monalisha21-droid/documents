//sum of n numbers in an array using for loop
var i, n=5, sum=0;
  arr = new Array(10, 12, 14, 16, 18);
  for(i=0; i<5; i++){
    sum = sum + arr[i];
  }
  document.write(sum);
//sum of n numbers in an array using while loop
var i=0, n=5, sum=0;
arr = new Array(10, 12, 14, 16, 18);
while(i<n){
    sum = sum + arr[i];
    i++; 
}
document.write(sum);
//sum of n numbers in an array using do while loop
var i=0, n=5, sum=0;
arr = new Array(10, 12, 14, 16, 18);
do{
    sum = sum + arr[i];
    i++;
}while(i<n);
document.write(sum);   

