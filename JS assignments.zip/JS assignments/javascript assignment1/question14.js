
//sum of an random number array
var i, n=5, sum=0;
  arr = new Array(40, 100, 1, 5, 25, 10);
  for(i=0; i<5; i++){
    sum = sum + arr[i];
  }
  document.write(sum);
  
  arry = [40, 100, 1, 5, 25, 10];
  //average of an array
  function calculateAverage(array) {
      var total = 0;
      var count = 0;
  
      array.forEach(function(item, index) {
          total += item;
          count++;
      });
  
      return total / count;
  }
  
  document.write(calculateAverage(arry));
  