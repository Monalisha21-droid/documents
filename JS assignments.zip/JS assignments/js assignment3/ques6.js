const obj={
    firstName:"Monalisha",
    lastName:"Sahoo"
}
let v1=eval("obj");
document.write(v1, "\n");
document.write(obj.firstName, "\n", obj.lastName);