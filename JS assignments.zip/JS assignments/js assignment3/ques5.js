const obj={
    firstName:"Rama",
    lastName:"Chandra"
}

obj.middleName="Krishna";
document.write(obj.middleName);
