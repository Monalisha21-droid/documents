*.txt
added two headings one paragraph in the index.html file



<!DOCTYPE html>
<html>
<body>

<h1>My First Heading</h1>
<h2>My Second Heading</h2>
<h3>My Second Heading</h3>
<p>My first paragraph.</p>

</body>
</html>
