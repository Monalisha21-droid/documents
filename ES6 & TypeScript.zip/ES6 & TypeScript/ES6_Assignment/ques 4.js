let names=['Karina','kangana','Karishma'];
let names1=names.map(item=>{
    return{ 
        name:item,
        length:item.length
    }
});
console.log(names1);