let organization = {
    name: "story",
    address: {
        city: "bangalore",
        street: "abcd",
        state: "Karnataka",
        pin_code: 759146
    }
};

let { pin_code } = organization;

console.log( pin_code);