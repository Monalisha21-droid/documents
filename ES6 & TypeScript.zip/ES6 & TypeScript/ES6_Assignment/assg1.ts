const a =10;
console.log(a);
function change(){
    let a=11;
    

}
console.log(a);