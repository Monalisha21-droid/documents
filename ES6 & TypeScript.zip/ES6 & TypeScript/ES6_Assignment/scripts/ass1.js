"use strict";
const a = 10;
console.log(a);
function change() {
     a = 11;
}
console.log(a);
//# sourceMappingURL=ass1.js.map